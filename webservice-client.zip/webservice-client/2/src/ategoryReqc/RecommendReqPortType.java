/**
 * RecommendReqPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ategoryReqc;

public interface RecommendReqPortType extends java.rmi.Remote {
    public ategoryReqc.ResultInfo1 recommendSyncReq(ategoryReqc.RecommendReq_Type recommendReq) throws java.rmi.RemoteException;
}
