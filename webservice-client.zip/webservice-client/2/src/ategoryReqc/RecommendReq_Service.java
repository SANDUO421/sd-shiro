/**
 * RecommendReq_Service.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ategoryReqc;

public interface RecommendReq_Service extends javax.xml.rpc.Service {
    public java.lang.String getRecommendReqHttpSoap11EndpointAddress();

    public ategoryReqc.RecommendReqPortType getRecommendReqHttpSoap11Endpoint() throws javax.xml.rpc.ServiceException;

    public ategoryReqc.RecommendReqPortType getRecommendReqHttpSoap11Endpoint(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
