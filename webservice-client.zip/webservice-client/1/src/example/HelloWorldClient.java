package example;

import ategoryReqc.ContentReq_ServiceLocator;

/**
 *
 * @author  	
 * @Time    2020/3/11
 */   public class HelloWorldClient {
  public static void main(String[] argv) {
  }
}
