/**
 * ContentReqPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ategoryReqc;

public interface ContentReqPortType extends java.rmi.Remote {
    public ategoryReqc.ResultInfo1 contentSyncReq(ategoryReqc.ContentReq_Type contentReq) throws java.rmi.RemoteException;
}
